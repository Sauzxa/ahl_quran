const List<String> relationship = [
  //TODO to lowercase
  "father",
  "mother",
  "Brother",
  "Sister",
  "uncle",
  "aunt",
  "grandfather",
  "grandmother",
  "other"
];
