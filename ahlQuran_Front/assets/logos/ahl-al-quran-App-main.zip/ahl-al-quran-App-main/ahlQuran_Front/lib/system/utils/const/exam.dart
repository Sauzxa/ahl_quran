const List<String> examTypes = [
  "all",
  "ajzaa",
];
