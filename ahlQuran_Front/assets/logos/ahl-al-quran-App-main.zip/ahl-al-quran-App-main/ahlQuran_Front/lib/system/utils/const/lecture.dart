const List<bool> trueFalse = [true, false];
const List<String> type = ["memorization and revision", "other"];
const List<String> category = ["male", "female", "both"];
int transformBool(bool value) => value ? 1 : 0;
