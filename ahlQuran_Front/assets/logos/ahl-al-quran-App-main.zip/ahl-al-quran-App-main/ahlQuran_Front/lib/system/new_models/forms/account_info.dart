import 'package:the_doctarine_of_the_ppl_of_the_quran/system/new_models/model.dart';

class AccountInfo implements Model {
  dynamic accountId;
  dynamic username;
  dynamic passcode;
  dynamic accountType = "student"; // Default value

  static const String guardian = 'guardian';
  static const String student = 'student';
  static const String teacher = 'teacher';
  static const String supervisor =
      'superviser'; // Note: 'superviser' as per backend

  static const List<String> validAccountTypes = [
    guardian,
    student,
    teacher,
    supervisor,
  ];

  AccountInfo({
    this.accountId,
    this.username,
    this.passcode,
    this.accountType,
  });

  factory AccountInfo.fromJson(Map<String, dynamic> json) => AccountInfo(
        accountId: json['account_id'],
        username: json['username'],
        passcode: json['passcode'],
        accountType: json['account_type'],
      );

  @override
  Map<String, dynamic> toJson() => {
        'account_id': accountId,
        'username': username,
        'passcode': passcode,
        'account_type': accountType,
      };

  @override
  bool get isComplete =>
      accountId != null &&
      username != null &&
      passcode != null &&
      accountType != null &&
      username.toString().isNotEmpty &&
      passcode.toString().isNotEmpty;
}
