package com.example.the_doctarine_of_the_ppl_of_the_quran

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
