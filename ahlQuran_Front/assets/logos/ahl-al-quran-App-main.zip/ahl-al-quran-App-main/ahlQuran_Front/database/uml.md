# UML Diagram
[link:](https://drive.google.com/file/d/1p4CtRMgw4WjN3HePNeJAX7UAxJY-4VxS/view?usp=sharing)
> **Note:** Open with draw.io to view it properly.
                         
