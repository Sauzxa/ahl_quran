# from auth import AuthSchema
# from admin import AdminSchema
# from president import PresidentSchema
# from supervisor import SupervisorSchema
# from teacher import TeacherSchema
# from student import StudentSchema
# from .guardian import GuardianSchema

# __all__ = [
#     "AuthSchema",
#     "AdminSchema",
#     "PresidentSchema",
#     "SupervisorSchema",
#     "TeacherSchema",
#     "StudentSchema",
#     "GuardianSchema",
# ]