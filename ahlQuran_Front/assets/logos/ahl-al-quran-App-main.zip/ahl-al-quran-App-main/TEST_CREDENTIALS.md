# Test Credentials for Ahl Quran Application

## Backend Status
✅ Backend is running on: `http://localhost:8000`
✅ API endpoints are accessible at: `http://localhost:8000/api/v1`

## Frontend Configuration
✅ Updated API configuration to point to correct backend URL
- Changed from: `http://localhost:80/quran/ahl_quran_backend/api/v1`
- Changed to: `http://localhost:8000/api/v1`

## Test Users

### President Account
- **Email**: `ahmed@example.com`
- **Password**: `SecurePass123`
- **Role**: President
- **School**: Al-Noor Academy
- **Status**: Active ✅

### Supervisor Account
- **Email**: `amine@gmail.com`
- **Password**: `amineamine12`
- **Role**: Supervisor
- **Status**: Active ✅

## How to Test

1. **Start the Flutter app** (if not already running)
2. **Go to the login page**
3. **Select role** from dropdown:
   - رئيس (President)
   - مشرف (Supervisor)
4. **Enter credentials** from above
5. **Click login**

## Registration Test

To test the registration form:
1. Go to "إنشاء حساب جديد" (Create Account)
2. Fill in all required fields:
   - الاسم الأول (First name)
   - اسم العائلة (Last name)
   - البريد الإلكتروني (Email)
   - كلمة المرور (Password - minimum 6 characters)
   - اسم المدرسة (School name - minimum 3 characters)
   - رقم الهاتف (Phone number - optional)
3. Click "إنشاء حساب"
4. You should see a message that the account is pending admin approval

## API Endpoints Verified

✅ `POST /api/v1/auth/president/login` - Working
✅ `POST /api/v1/auth/supervisor/login` - Working
✅ `POST /api/v1/auth/president/register` - Available

## Notes

- Passwords are currently stored as plain text (not hashed) in the database
- New registrations require admin approval before users can login
- The frontend now correctly points to port 8000 instead of port 80
